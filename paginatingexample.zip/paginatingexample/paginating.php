<?php
// Start the session
//session_start();
  
?>

<html>
<body>
<style>
.all{
	width:50%;
	margin:0 auto;
	margin-top:55px;
	
}
.pagination a{
	color:black;
	float:left;
	padding:8px 16px;
	text-decoration:none;
	transition:background-color .3s;
}
.pagination a.active{
	background-color:#4CAF50;
	color:#fff;
}
.pagination{
	margin-top:30px;
}
.pagination a:hover:not(.active){
	background-color:#ddd;
}
table, td{
   
}

table {
    border-collapse: collapse;
    width: 50%;
}


}
img {
   display: block;
   width:200%; 
  
   
}
input[type=button], input[type=submit], input[type=reset] {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 16px 32px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
<div class="all">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 	
else{
	
}

   $total="select * from product";

   $count=$conn->query($total);
   $nr=$count->num_rows;
   
   $page=1; 
   $item_per_page=2;
   $totalpages=ceil($nr/$item_per_page);
   if(isset($_GET['page'])&& !empty($_GET['page']))
   {
	   $page=$_GET['page'];
	   
   }
    
	$offset=($page-1)*$item_per_page;
	$sql = "select * from product limit $item_per_page offset $offset";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
   
		while($row = $result->fetch_assoc()) {
			
			$id=$row["id"];
			if(isset($_GET['buy'])){
            $_GET['id']=$id;
            echo $_GET['id'];			
                     }
					   else echo "no value";
echo "<table>";
 echo "<tr>";
 echo   "<td rowspan='3' style='width:100%'><img src='".$row['image']."'></td>";
   echo  "<td style='width:30%'>"."catname:".$row["category"]."</td>";
  echo"</tr>";
 echo "<tr>";
    
   echo "<td style='width:30%'>"."Description:".$row["description"]."</td>";
  echo "</tr>";
  echo "<tr>";
    
   echo "<td>"."price:".$row["vandute"]."</td>";
  echo "</tr>";
  echo "<tr>";
  echo "<td>"."<form action='show.php' method='get'><input type='submit' name='buy' value='BUY'></form>"."</td>";
  echo "</tr>";
echo "</table>";
		}
		 echo"<div class='pagination'>";
		 for($i=1;$i<=$totalpages;$i++){
			 if($i==$page){
			 echo '<a class="active">'.$i.'</a>';
			 }
				 else{
					 echo '<a href="paginating.php?page='.$i.'">'.$i.'</a>';
					 
				 }
			 }
			 echo "</div>";
		 
		 }
	
	
	  
   ?>
   <div>
</body>
</html>