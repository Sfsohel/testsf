<?php
//session_start();
echo $_GET['id'];

?>