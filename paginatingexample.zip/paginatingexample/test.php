<html>
<body>
<style>
.all{
	width:50%;
	margin:0 auto;
	margin-top:55px;
	
}
.pagination a{
	color:black;
	float:left;
	padding:8px 16px;
	text-decoration:none;
	transition:background-color .3s;
}
.pagination a.active{
	background-color:#4CAF50;
	color:#fff;
}
.pagination{
	margin-top:30px;
}
.pagination a:hover:not(.active){
	background-color:#ddd;
}
table, td{
    border: 1px solid black;
}

table {
    border-collapse: collapse;
    width: 50%;
}


}
img {
   display: block;
   width:200%; 
  
   
}
</style>
<div class="all">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 	
else{
	
}

   $total="select * from product";

   $count=$conn->query($total);
   $nr=$count->num_rows;
   
   $page=1; //added by myself
   $item_per_page=2;
   $totalpages=ceil($nr/$item_per_page);
   if(isset($_GET['page'])&& !empty($_GET['page']))
   {
	   $page=$_GET['page'];
	   
   }
    //else{       commented
	//	$page=1; commented
	$offset=($page-1)*$item_per_page;
	$sql = "select * from product limit $item_per_page offset $offset";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
   
		while($row = $result->fetch_assoc()) {
			echo $row["image"];
			
echo "<table>";
 echo "<tr>";
 
 echo   "<td style='width:34%'><img src=".$row["image"]."></td>";
   echo "<td>Smith</td>";
  echo"</tr>";
 
echo "</table>";
		}
		 
		 }
		 
	
	//}  commented
	  
   ?>
   <div>
</body>
</html>